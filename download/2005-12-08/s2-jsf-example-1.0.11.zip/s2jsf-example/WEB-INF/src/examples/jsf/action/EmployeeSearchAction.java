package examples.jsf.action;

public interface EmployeeSearchAction {

	public String checkSearchCount();
	
	public String goEditForCreate();
}
