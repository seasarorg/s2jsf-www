package examples.jsf.action;

public interface EmployeeSearchInitAction {

	public String initialize();
}
