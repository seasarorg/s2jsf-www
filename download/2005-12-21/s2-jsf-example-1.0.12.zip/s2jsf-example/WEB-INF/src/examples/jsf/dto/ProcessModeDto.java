package examples.jsf.dto;

public class ProcessModeDto {

	private int processMode;

	public int getProcessMode() {
		return processMode;
	}
	
	public void setProcessMode(int processMode) {
		this.processMode = processMode;
	}
}
