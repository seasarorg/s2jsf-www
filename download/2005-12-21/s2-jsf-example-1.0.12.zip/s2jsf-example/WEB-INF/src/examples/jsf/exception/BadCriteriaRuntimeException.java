package examples.jsf.exception;

public class BadCriteriaRuntimeException extends AppRuntimeException {

	public BadCriteriaRuntimeException() {
		super("examples.jsf.BadCriteria");
	}
}