package examples.jsf.dto;

import java.util.Date;

public class ConverterDto {

	private Date aaa = new Date();

	public Date getAaa() {
		return aaa;
	}
	
	public void setAaa(Date aaa) {
		this.aaa = aaa;
	}
}
