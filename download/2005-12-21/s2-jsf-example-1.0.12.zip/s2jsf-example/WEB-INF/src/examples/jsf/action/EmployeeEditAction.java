package examples.jsf.action;

public interface EmployeeEditAction {

	public String goConfirm();
	
	public String goPrevious();
}
