/**
 *
 */
package examples.jsf.dto;

/**
 * @author shot
 */
public class HelloDto {

    private String name = "S2JSF";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
