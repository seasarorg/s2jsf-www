select dname
from dept
where deptno = /*deptno*/10