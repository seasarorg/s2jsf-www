package examples.jsf.dto;

import examples.jsf.entity.Department;

public class DepartmentDto extends Department {
}
