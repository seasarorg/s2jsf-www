package examples.jsf.action;

public interface EmployeeEditInitAction {

	public String initialize();
}
