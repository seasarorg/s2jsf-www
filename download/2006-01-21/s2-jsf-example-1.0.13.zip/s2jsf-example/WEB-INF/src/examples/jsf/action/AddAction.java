package examples.jsf.action;

public interface AddAction {

	public String calculate();
}