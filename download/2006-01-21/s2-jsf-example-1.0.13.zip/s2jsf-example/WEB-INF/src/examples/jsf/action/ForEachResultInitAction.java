package examples.jsf.action;

public interface ForEachResultInitAction {

	public String initialize();
}
