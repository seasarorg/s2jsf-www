package examples.jsf.logic;

import examples.jsf.dto.AddDto;

/**
 * @author higa
 *
 */
public interface AddLogic {

	public int calculate(AddDto addDto);
}
