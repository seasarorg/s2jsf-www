package examples.jsf.action;

public interface Page1Action {

	public String throwException();
}
