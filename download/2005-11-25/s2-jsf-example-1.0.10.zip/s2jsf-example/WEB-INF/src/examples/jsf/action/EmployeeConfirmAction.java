package examples.jsf.action;

public interface EmployeeConfirmAction {

	public String store();
	
	public String goPrevious();
}
