package examples.jsf.action;

public interface ForEach2ListAction {

	public String update();
	
	public String addRow();
}
