package examples.jsf.action;

public interface EmployeeListInitAction {

	public String initialize();
}
