package examples.jsf.action;

public interface EmployeeListAction {

	public String goNext();
}
