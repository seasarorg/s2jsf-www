package examples.jsf.action;

public interface Page2InitAction {

	public String initialize();
}
