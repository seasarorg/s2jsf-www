package examples.jsf.action;

public interface EmployeeConfirmInitAction {

	public String initialize();
}
