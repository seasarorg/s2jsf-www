/**
 *
 */
package examples.jsf.dto;

/**
 * @author shot
 */
public class RenderedDto {

    private String name = "aaaa";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
